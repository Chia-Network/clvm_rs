/* tslint:disable */
/* eslint-disable */
/**
* @param {Uint8Array} program
* @param {Uint8Array} args
* @returns {Uint8Array}
*/
export function run_clvm(program: Uint8Array, args: Uint8Array): Uint8Array;
