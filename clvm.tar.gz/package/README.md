Build with

```
wasm-pack build
```
