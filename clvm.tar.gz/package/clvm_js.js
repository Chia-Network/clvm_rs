import * as wasm from "./clvm_js_bg.wasm";
export * from "./clvm_js_bg.js";